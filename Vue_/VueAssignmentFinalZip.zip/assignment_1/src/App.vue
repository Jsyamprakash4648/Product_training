<template>
  <div class="maindiv1">
        <nav class="navdiv">
            <h1>Library Management System</h1>
            <p class="datenow">{{CurrentDate}}</p>
        </nav>
        <div class="maindiv2">
            <div class="sidebardiv">
                    <button class="sidebuttons" @click="dishome()">Home</button>
                    <button class="sidebuttons" @click="disbook()">Books</button>
            </div>
            <div class="contentdiv" v-if="displayhome">
              
                        <Home :BooksData="Books" @add:book_2="funAddnewbook" />
                        
            </div>

            <div class="contentdiv" v-else>
              
                        <!-- <Home :BooksData="Books"/> -->
                        <Book :BooksData="Books" />
                        <!-- <NewBook @add:book="funAddnewbook"/> -->
            </div>
            
        </div>

    </div>
  
    <!--  -->
  
</template>

<script>
 import Book from './components/Book.vue';

 import Home from './components/Home.vue';

 



export default {

  
  name: 'App',
  components: {
   
      Home,
      Book,
      
     
    
  },
  data()
  {
    return {
      
      CurrentDate:'',
       displayhome:true,
      

                Books:[
                  {
                    ID:1,
                    BookName:'C#',
                    Author:'Thomas',
                    Category:'Education',
                    Published:'friday,20 December 2019',
                    Description:'its about C# In Details page show description about books as like below mock screenshot,'
                  },

                  {
                    ID:2,
                    BookName:'Java',
                    Author:'Stephen',
                    Category:'Education',
                    Published:'friday,20 December 2019',
                    Description:'its about Java  In Details page show description about books as like below mock screenshot,'
                  },

                  {
                    ID:3,
                    BookName:'Avathar',
                    Author:'James',
                    Category:'Movies',
                    Published:'friday,20 December 2019',
                    Description:'its about Avathar In Details page show description about books as like below mock screenshot,'
                  },

                  {
                    ID:4,
                    BookName:'Avengers',
                    Author:'Joseph',
                    Category:'Movies',
                    Published:'friday,20 December 2019',
                    Description:'its about Avengers In Details page show description about books as like below mock screenshot,'
                  },

                  {
                    ID:5,
                    BookName:'frog&food',
                    Author:'Lokesh ',
                    Category:'Stories',
                    Published:'friday,20 December 2019',
                    Description:'its about frog&food In Details page show description about books as like below mock screenshot,'
                  },

                  {
                    ID:6,
                    BookName:'friends',
                    Author:'Kanagaraj',
                    Category:'Stories',
                    Published:'friday,20 December 2019',
                    Description:'its about friends In Details page show description about books as like below mock screenshot,'
                  },
                ],
    }
  }
  ,
  mounted(){
    this.updatecurrentdate();
    
  },
  methods:
  {
    updatecurrentdate()
    {
        const now=new Date();
        const fdate=now.toDateString();
        this.CurrentDate=fdate;
       
    },
    disbook()
    {
     
      this.displayhome=false;
    },
    dishome()
    {
        this.displayhome=true;
    },
    funAddnewbook(arr)
    {
      console.log(arr);
      const  id=this.Books.length>0 ? this.Books[this.Books.length-1].ID+1:1
      const Ab={...arr,ID:id}

      this.Books=[...this.Books,Ab]
    }
    
  },
  
     
  
  
}
</script>

<style>
.datenow
{
  margin-right: 10px;
  margin-top: 30px;
}

.maindiv1
{
    /* background-color: aqua; */
    border: 1px solid black;
    width: 1000px;
    height: 600px;
   margin: auto;
     /* font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif */
}
.navdiv
{
    display: flex;
    justify-content: space-between;
    border: 1px solid black;
}

.maindiv2
{
    /* background-color: blue; */
    display: flex;
    font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif
    
}
.sidebardiv
{
    /* background-color: yellowgreen; */
    width: 200px;
    height: 530px;
    border: 1px solid black;
     font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif
}

.sidebuttons
{
    width: 100%;
    font-weight: 900;
    font-size:large;
     border: 1px solid black;
    
}
.contentdiv
{
    /* background-color: brown; */
    width: 100%;
    border: 1px solid black;
}
</style>
