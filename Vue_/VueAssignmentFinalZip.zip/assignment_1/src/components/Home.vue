<template>
<div>
    <button class="addbookbtn" v-if="addbook"  @click="funAddbook()">New Book</button>
    <table v-if="addbook">
        <tr>
            <td class="headtd"><b>Total books</b></td>
            <td><b>88</b></td>
        </tr>

        <tr>
            <td class="headtd">Total books issued </td>
            <td>34</td>
        </tr>

        <tr>
            <td class="headtd">Total books lost</td>
            <td>12</td>
        </tr>

        <tr>
            <td class="headtd">Newly added book</td>
            <td>Reading now</td>
        </tr>

        <tr>
            <td class="headtd">Upcoming books</td>
            <td>The girl Who kicked the hornets's Nest,Flowers for Algernon</td>
        </tr>

    </table>
    <div v-else>

            <NewBook @add:book="funAddnewbook" />
    </div>
</div>


  
</template>
<script>
import NewBook from './NewBook.vue'
export default {

     components: {
   
                     NewBook,
            },
    

    name:"Home-Page",
    data()
    {
       return{
                    addbook:true,
                    newbook_2:'',
             } 
    },
    methods:
    {
        funAddbook()
        {
            this.addbook=false;
        },
        funAddnewbook(newbook1)
        {

            this.newbook_2=newbook1;
            this.$emit('add:book_2',this.newbook_2);
        }


    }
}
</script>
<style scoped>
table
{
    border-collapse: collapse;
    border: 3px solid black;
    width: 90%;
    margin: auto;
}
td
{
    padding:32px;
    border-bottom: 3px solid black;
    font-weight: 200;
    text-align: center;
}
.headtd
{
    text-align: left;
    /* background-color: red; */
    width: 50%;
}
.addbookbtn
{
   margin-left: 86%;
   padding: 6px;
   margin-bottom: 5px;
   margin-top: 5px;
   
   
}
</style>