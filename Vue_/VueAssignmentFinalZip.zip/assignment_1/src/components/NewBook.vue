<template>
 <div class="addbookdiv">
    <h4>Enter new Book Details</h4>
    <form v-on:submit.prevent="funhandleSubmit">
        <table>
            <tr>
                <th>Title:</th>
                <td><input type="text"
                        v-model="newbook.BookName"
                        ></td>
            </tr>

             <tr>
                <th>Author:</th>
                <td><input type="text"
                    v-model="newbook.Author"></td>
            </tr>

             <tr>
                <th>Published Date:</th>
                <td><input type="date"
                    v-model="newbook.Published" ></td>
            </tr>
            <tr>
                <th>Category</th>
                <td><select name="" id="" v-model="newbook.Category" >
                        <option value="Education">Education</option>
                         <option value="Movies">Movies</option>
                          <option value="Stories">Stories</option>
                    </select></td>
            </tr>

             <tr>
                <th>Description:</th>
                <td><textarea name="" id="" cols="30" rows="10"
                        v-model="newbook.Description" ></textarea></td>
            </tr>
            <tr>
                <td colspan="2" class="addbookbtnTR">
                    <button class="Addbtn">Add</button>
                </td>
            </tr>
        </table>
    </form>
 </div>
</template>

<script>
export default {
    data()
    {
        return{
            newbook:
            {
                BookName:'',
                Author:'',
                Category:'',
                Published:'',
                Description:''
              

            }
        }
    },
    methods:
    {
        funhandleSubmit()
        {

            if(this.newbook.BookName=='' || this.newbook.Author==''|| this.newbook.Category==''|| this.newbook.Published==''|| this.newbook.Description=='')
            {
                alert("please fill all required feilds.")
                return '';
            }
            //change datefromat
            this.newbook.Published=new Date(this.newbook.Published).toDateString();
          
            this.$emit('add:book',this.newbook);
            alert("Your Book Added Successfully...")
            this.newbook=
            {
                BookName:'',
                Author:'',
                Category:'',
                Published:'',
                Description:''
                }
            
        }
    }

}
</script>

<style scoped>

.Addbtn
{
    padding:5px;
    margin-top: 12px;
    border-radius: 5px;
    width: 20%;
   margin-right: 25%;
}

table
{
    width:60%;
    text-align: left;
    /* background-color: aquamarine; */
}
h4
{
    text-align: left;
    margin-left: 15%;
}
table input,textarea
{
    width: 90%;
    border: 3px solid black;
    margin-left: 10%;
    padding: 2%;
    margin:1%
}
select
{
    width: 96%;
    border: 3px solid black;
    margin-left: 10%;
    padding: 2%;
     margin:1%

}
.addbookdiv
{
    /* padding:1%; */
    font-size:x-large;
    padding-left: 3%;
}
.addbookbtnTR
{
    text-align: right;
}
.addbookbtnTR button
{
    border: 2px solid black;
}

</style>

