<template>

<div>
    <!-- <select v-if="istrueDetailsContent" v-model="selectedvalue">
        <option value="all">All</option>
        <option value="education">Education</option>
         <option value="movies">Movies</option>
          <option value="stories">Stories</option>
    </select>
    <button @click="Searchcategory" class="searchbutton"  v-if="istrueDetailsContent">Search</button> -->

     <select v-if="istrueDetailsContent" v-model="selectedvalue" @change="Searchcategory" >
        <option value="all">All</option>
        <option value="Education">Education</option>
         <option value="Movies">Movies</option>
          <option value="Stories">Stories</option>
    </select>
    <!-- <button   v-if="istrueDetailsContent">Search</button> -->

<!-- ______________________________________________________________________________________________ -->
    <table v-if="istrueDetailsContent" class="contenttable1">
        <tr><th>Title</th>
             <th>Author</th>            
             <th>Category</th>
             <th>Details</th>
        </tr>
        <tbody v-if="istrue">
                 <tr v-for="book in BooksData" :key="book.ID">
                     <td>{{book.BookName}}</td>
                     <td>{{book.Author}}</td>
                     <td>{{book.Category}}</td>
                     <button @click="Detailspage(book.ID)" class="detailsbtn">More...</button>
                 </tr>
        </tbody >
            
             <tbody v-else>
                             <tr v-for="book in filteredcontent" :key="book.ID">
                                          <td>{{book.BookName}}</td>
                                          <td>{{book.Author}}</td>
                                          <td>{{book.Category}}</td>
                                          <button @click="Detailspage(book.ID)" class="detailsbtn">More...</button>
                              </tr>
             </tbody>
    </table>

    <table v-else class="detailtabble" > 
        <tr class="detaletableTr">
            <th>Title of the book:</th>
            <th>{{detailsContent[0].BookName}}</th>
        </tr>
        <tr>
            <th>Author of the book: </th>
            <th>{{detailsContent[0].Author}}</th>
        </tr>
        <tr>
            <th>Date of published</th>
            <th>{{detailsContent[0].Published}}</th>
        </tr>
        <tr>
            <th colspan="2"><h4>Description</h4><p class="description">{{detailsContent[0].Description}}</p></th>
        </tr>
        <tr>
            <th colspan="2">  <button @click="backtobookDfun()" class="Booksbtn">Book</button></th>
        </tr>
    </table>
   
</div>
    
</template>

<script>
export default {
    name:'Book-table',
    data()
    {
        return {
            selectedvalue:'',
            filteredcontent:'',
            detailsContent:'',

            istrueDetailsContent:true,
            
            istrue:true
            }
    },
    props:
    {
        BooksData:Array,
        
    },
    methods:
    {
        Searchcategory()
        {   
        this.istrue=false;  
        if(this.selectedvalue=='all')
        {
            
            return this.istrue=true
        }
       
            this.filteredcontent=this.BooksData.filter((book)=>{
            return this.selectedvalue==book.Category
           })
        },
        Detailspage(id)
        {
            // alert(id)
            this.detailsContent=this.BooksData.filter((book)=>
            {
                return book.ID==id
            });
            //console.log(this.detailsContent)
             this.istrueDetailsContent=false;


        },
        backtobookDfun()
        {
            this.istrueDetailsContent=true;
            // this.detailsContent[0]="";
           
        }
    }
}
</script>

<style  scoped>

.detailsbtn
{
    padding:5px;
    margin-top: 12px;
    border-radius: 5px;
    width: 40%;
}
.Booksbtn
{
    padding:5px;
    margin-top: 12px;
    border-radius: 5px;
    width: 20%;
    align-content: left
}
.contenttable1
{
    border-collapse: collapse;
    /* border: 2px solid black; */
    width: 100%;
    font-size: large;
    table-layout: fixed;
   
}
td
{
    
    padding:15px;
/* border-bottom: 2px solid black; */
    font-weight: 600;
}
th
{
    text-align: left;
    border: 2px solid black;
     font-size: x-large;
}
tr
{
    
    text-align: left;
    border: 1px solid black;
}
select
{
    width: 10%;
    margin-left: 75%;
    margin-top: 2%;
     margin-bottom: 2%;
     padding: 3px;
   
}

.searchbutton
{
    margin-left: 1%;
    border-radius: 5px;
    padding: 3px;
}

.detailtabble
{
    width: 80%;
    /* margin-left: 5%; */
    /* padding: 1%; */
    border: none;
}
.detailtabble th
{
    padding: 2.5%;
   
    border: none;
}

.description
{
    font-weight: 100;
    width: 500px;
}


</style>