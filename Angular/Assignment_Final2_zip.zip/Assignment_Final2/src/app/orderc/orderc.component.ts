import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectedservicesService } from '../selectedservices.service';

@Component({
  selector: 'app-orderc',
  templateUrl: './orderc.component.html',
  styleUrl: './orderc.component.css'
})
export class OrdercComponent {
  constructor(private _router:Router,private _arouter:ActivatedRoute,private _datservice:SelectedservicesService){}

  public ordercount:any=this._datservice.cartitems.length;

  gotohome()
  {
    this._router.navigate(['../'],{relativeTo:this._arouter});
    this._datservice.orderclear();
    
    
  }

  


}
