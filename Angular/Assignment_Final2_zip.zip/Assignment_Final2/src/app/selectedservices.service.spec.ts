import { TestBed } from '@angular/core/testing';

import { SelectedservicesService } from './selectedservices.service';

describe('SelectedservicesService', () => {
  let service: SelectedservicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SelectedservicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
