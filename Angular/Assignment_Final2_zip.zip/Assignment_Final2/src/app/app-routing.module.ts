import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SelectedComponent } from './selected/selected.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { CartitemsComponent } from './cartitems/cartitems.component';
import { OrdercComponent } from './orderc/orderc.component';
import { LoginComponent } from './login/login.component';



const routes: Routes = [
  {path:"selected",component:SelectedComponent},
  {path:"",component:ProductlistComponent}, 
  {path:"cartietms",component:CartitemsComponent},
  {path:"order",component:OrdercComponent},
  {path:"loginC",component:LoginComponent}
 
   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
// export const routingcomponents=[SelectedComponent]