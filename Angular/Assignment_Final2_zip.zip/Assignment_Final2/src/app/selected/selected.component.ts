import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectedservicesService } from '../selectedservices.service';

@Component({
  selector: 'app-selected',
  templateUrl: './selected.component.html',
  styleUrl: './selected.component.css'
})
export class SelectedComponent implements OnInit {
  oneproduct:any;
  quantity:any;
  // cartitems:any=[{"imgurl":"",}];



  constructor(private _router:Router,private dataservice:SelectedservicesService,private _arouter:ActivatedRoute){}
 

  ngOnInit() {

    
      // const navigation=this._router.getCurrentNavigation();
      // console.log(navigation);
      // if(navigation && navigation.extras && navigation.extras.state)
      //   {
      //     console.log("in ngOnInit")
      //     this.oneproduct=navigation.extras.state['product'];
      //   };
      this.oneproduct=this.dataservice.getProduct();
      console.log(this.oneproduct);
      



  }

  // <img  [src]="oneproduct.imageurl" alt="brinjal" style="width:100%">
  // <div class="container">
  //   <h4><b>{{oneproduct.title}}</b></h4> 
  //   <span>{{oneproduct.discription}}</span> 
  //   <p> <b>price:  </b> <span>{{oneproduct.Price}}</span></p> 
   

  funcountinput()
  {
    // (document.getElementsByClassName("vincent")[0] as HTMLDivElement).style.display="none";
    // (document.getElementsByClassName("countpromt")[0] as HTMLDivElement).style.display="block";

    var numericRegex = /^[0-9]+$/;

   this.quantity=Number( prompt("Enter quanitity you need"));
   //alert("you have entered  "+ this.quantity);
   if(this.quantity==0 || this.quantity=="" )
    {
      alert("0 is not valid please enter a valid number ");
    }
  else if(!numericRegex.test(this.quantity))
    {
      alert("Invalid Input please enter a valid number");
    }
    else
    {
      this.dataservice.addcart(this.oneproduct.imageurl,this.oneproduct.title,this.oneproduct.Price*this.quantity,this.quantity);
      alert("sucesssfully added to cartitem services")
     this._router.navigate(['../'],{relativeTo:this._arouter});
    }
    
  }
 

  
}
 