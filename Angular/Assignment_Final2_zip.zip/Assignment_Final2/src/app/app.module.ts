import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SelectedComponent } from './selected/selected.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { CartitemsComponent } from './cartitems/cartitems.component';
import { OrdercComponent } from './orderc/orderc.component';
import { LoginComponent } from './login/login.component';



@NgModule({
  declarations: [
    AppComponent,
    SelectedComponent,
    ProductlistComponent,
    CartitemsComponent,
    OrdercComponent,
    LoginComponent,
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {


  
 }
