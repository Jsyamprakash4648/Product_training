import { Component, OnInit } from '@angular/core';
import { SelectedservicesService } from '../selectedservices.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-cartitems',
  templateUrl: './cartitems.component.html',
  styleUrl: './cartitems.component.css'
})
export class CartitemsComponent implements OnInit {
  
 cartproduct:any;
totalprice:any;

  constructor(private dataserivece:SelectedservicesService,private _router:Router,private _arouter:ActivatedRoute){}
  
  ngOnInit() {
   
    this.cartproduct=this.dataserivece.getcartitems();
    this.totalprice=this.dataserivece.totalprice;
     console.log(this.cartproduct);
    // console.log(this.cartproduct.imgtitle);
    // console.log(this.cartproduct.imageurl);

  }

  
  gotoOrderC()
  {
    //  this.cartproduct="nothig";
    //  this.totalprice="nothig";
    this._router.navigate(['/order'],{relativeTo:this._arouter});
    
  }

  

 
}
