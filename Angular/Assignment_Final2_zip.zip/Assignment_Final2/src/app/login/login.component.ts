import { Component, OnInit } from '@angular/core';
import { SelectedservicesService } from '../selectedservices.service';
import { ActivatedRoute, Router } from '@angular/router';
import { tick } from '@angular/core/testing';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  
  //userinfo:any;
  constructor(private _dataservice:SelectedservicesService,private _router:Router,private a_router:ActivatedRoute){}
  ngOnInit() {
   
   
  }



  validate()
  {
    
    let usern=(document.getElementById("UserName")as HTMLInputElement).value;
    let pass=(document.getElementById("Password")as HTMLInputElement).value;

    let userConirmation=this._dataservice.getuserdetails(usern,pass);

    if(userConirmation)
      {
        // this._dataservice.changetoexistinguser();
        this._router.navigate([""],{relativeTo:this.a_router});

      }
    else
    {
      alert("please enter valid details...");
    }

}


goback()
{
  this._router.navigate(['../'],{relativeTo:this.a_router});
}
}
