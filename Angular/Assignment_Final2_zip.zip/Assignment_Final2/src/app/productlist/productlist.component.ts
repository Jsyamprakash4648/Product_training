import { state } from '@angular/animations';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectedservicesService } from '../selectedservices.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrl: './productlist.component.css'
})
export class ProductlistComponent {


  public productdetailsarray=[
    {
      imageurl:"../assets/images/carrot.jpg",
      title:"carrot",
      discription:"this is carrot",
      Price:10

    },
    {
      imageurl:"../assets/images/coconut.jpg",
      title:"coconut",
      discription:"this is coconut",
      Price:20

    },
    {
      imageurl:"../assets/images/cucumber.jpg",
      title:"cucumber",
      discription:"this is cucumber",
      Price:30

    },
    {
      imageurl:"../assets/images/tea.jpg",
      title:"tea",
      discription:"this is tea",
      Price:40

    },
    {
      imageurl:"../assets/images/tomato.jpg",
      title:"tomato",
      discription:"this is tomato",
      Price:50

    },
    {
      imageurl:"../assets/images/turmericpowder.jpg",
      title:"turmericpowder",
      discription:"this is turmericpowder",
      Price:60

    },
    {
      imageurl:"../assets/images/onion images.jpg",
      title:"onion",
      discription:"this is onion",
      Price:70

    },
    {
      imageurl:"../assets/images/sugar.jpg",
      title:"sugar",
      discription:"this is sugar",
      Price:80

    },
    {
      imageurl:"../assets/images/rice.jpg",
      title:"rice",
      discription:"this is rice",
      Price:90

    }

  ];
  constructor(private _router:Router,private dataservice:SelectedservicesService,private _arouter:ActivatedRoute){}

  isvalidateuser:any;
  validSubscription:any;
  ngOnInit()
   {

    this.validSubscription = this.dataservice.valid$.subscribe((valid: boolean) => {
      this.isvalidateuser = valid;
      
          // this.isvalidateuser=this.dataservice.currentusername;
        
    });
  }











// ___________________________________________________



  gotoselected(product:any)
  {

    if(this.isvalidateuser)
      {
            //   console.log(product);
  this._router.navigate(['selected'],{relativeTo:this._arouter})
  this.dataservice.setProduct(product);
    console.log("sent succefully");
      }
      else{alert("please Login fisrt..")}
  
  }

}
