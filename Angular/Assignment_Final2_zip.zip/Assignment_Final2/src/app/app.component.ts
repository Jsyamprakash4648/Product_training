import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectedservicesService } from './selectedservices.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'Assignment';

  public isvalidateuser:any;

  validSubscription: any;

  public currentuser:any;

  

  constructor(private _router:Router,private _arouter:ActivatedRoute,private _dataservice:SelectedservicesService){}
  ngOnInit()
   {

    this.validSubscription = this._dataservice.valid$.subscribe((valid: boolean) => {
      this.isvalidateuser = valid;
      
          this.currentuser=this._dataservice.currentusername;
        
    });

   

  }
  // this.isvalidateuser=this._dataservice.valid;

  gotocart()
  {
    let itemcount:any=Number(this._dataservice.cartitems.length);
      if(itemcount==0)
        {

              alert("No items in the Cart");
        }
        else
        {
          this._router.navigate(['cartietms'],{relativeTo:this._arouter});
        }
   
  }

  gotologin()
  {
    this._router.navigate(['loginC'],{relativeTo:this._arouter});
  }



public flag=false;

gotorprofile()
  {
    if(!this.flag)
      {
        (document.getElementById("dropdowncontentid")as HTMLDivElement).style.display="block";
        //____________________
        
        
        this.flag=true;

      }
      else
      {
        (document.getElementById("dropdowncontentid")as HTMLDivElement).style.display="none";

      // (document.getElementById("logoutbutton") as HTMLDListElement).style.display="block";
        

        //  (document.getElementById("logoutbutton") as HTMLDListElement).style.display="block";
        //  (document.getElementById("name") as HTMLDListElement).style.display="block";
        
        this.flag=false;
      }
   
  }
  // usericonid
  // onMouseLeave()
  // {
  //   (document.getElementById("dropdowncontentid")as HTMLDivElement).style.display="none";
  // }

   
  gotologout()
  {
  
    //window.location.reload();

  this._dataservice.logout();

  (document.getElementById("dropdowncontentid")as HTMLDivElement).style.display="none";

  this.flag=false;

   //(document.getElementById("logoutbutton") as HTMLDListElement).style.display="none";


  // (document.getElementById("name") as HTMLDListElement).style.display="none";
    
   

  }


  
    
  

  




  

  

}
