import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SelectedservicesService {

  public product: any[]=[];
  public cartitems:any[]=[];
  public totalprice:number=0;
  public users:any[]=[
                        {"username":"Syam","passwrord":"12345678"},
                        {"username":"Abcd","passwrord":"12121313"}
                      ];

  public valid:boolean=false;

  

 

  constructor(private _router:Router,private _arouter:ActivatedRoute) { }

  setProduct(product: any) {
    this.product = product;
  }

  getProduct() {
    return this.product;
  }



  addcart(imgurl:any,imgtitle:any,price:any,quantity:number)
  {
   let  flag:boolean=false;
     
      for(let item of this.cartitems)
        {
          if(item.imgtitle==imgtitle)
            {
                item.quantity=Number(item.quantity+quantity);
                item.price=Number(item.price+price*quantity);
                this.totalprice=this.totalprice+price*quantity;
                
                
                flag=true;
            }
        }

        if(!flag)
          {
            this.cartitems.push({imgurl,imgtitle,price,quantity});
            this.totalprice=this.totalprice+price;
    
          };
  };

  getcartitems()
  {
    return this.cartitems;
  }


  // ___________________________________________________________________


  private _validSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public valid$ = this._validSubject.asObservable();

  public currentusername:any;


  getuserdetails(user11:any,password22:any):boolean
  {
    //let flag:boolean=true;
        for(let user of this.users)
      {
        if(user.username==user11 && user.passwrord==password22)
          {

            this.currentusername=user11;
            this._validSubject.next(true);

        
            
            
            return true;
            
          }
      }
      this._validSubject.next(false);
          return false;
        
     

  }
//______________________________________________________________________________________________________________
  // changetoexistinguser()
  // {
  //   this.valid=true;
  // }

    // public Logout:any;
//_______________________________________________________________________________________________________________
  logout()
  {
    //this.Logout="logout";
    this._validSubject.next(false);
    this._router.navigate(['/'],{relativeTo:this._arouter});
  }

  orderclear()
  {
    this.cartitems=[];
    this.totalprice=0;
  }

  


}
