import React from 'react'

const NewUser = ({handleSubmit,setnewusers1,newuser1,newusername2,setnewusersname2}) => {
  return (
    <div className='box1'>
                        <form onSubmit={(e)=>handleSubmit(e)}>
                        <h1>Add user</h1>
                        <label>Name</label><br/>
                        <input type='text'
                        value={newuser1}
                         onChange={(e)=>setnewusers1(e.target.value)}
                          />
                        
                        <br/><br/>
{/*  */}
                        <label>Username</label><br/>
                        <input type='text'
                        value={newusername2}
                        onChange={(e)=>setnewusersname2(e.target.value)}
                        
                         /><br/>

                        < button type='Submit'  className='addnewuserbutton' >Add new user</button>
                        </form>
                            
                     </div>
  )
}

export default NewUser