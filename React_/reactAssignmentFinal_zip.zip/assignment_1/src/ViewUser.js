import React from 'react'

const ViewUser = ({users,handleEdit,handledelete}) => {
  return (
    <div className='box2'>
      <h1>View User</h1>
    <table>
       <thead>
           <tr>
           <th>Name</th>
           <th>Username</th>
           <th>Actions</th>
           
           </tr>
       </thead>
       <tbody>
               {users.map((user)=>

               
               <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.username}</td>
                <td>  
                       <button className='editdeltbtn' onClick={()=>handleEdit(user.id)}>Edit</button>
                       <button className='editdeltbtn' onClick={()=>handledelete(user.id)}>Delete</button></td>
               </tr>
               )}
       </tbody>      
               
    </table>
</div>
  )
}

export default ViewUser