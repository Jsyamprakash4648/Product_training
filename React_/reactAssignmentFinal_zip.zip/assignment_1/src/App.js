
import { Link, Route, Routes } from 'react-router-dom';
import './App.css';
import Contact from './Contact';
import Home from './Home';
import Users from './Users';

function App() {
  return (
    <div className="wholeContainer">
      <nav> 
        <div className='navicons' >
         <Link to='/about' className='linkk' > <button className='navbtns'>About</button></Link>
         <Link to='/users' className='linkk' ><button className='navbtns'>Users</button></Link>
            <Link to='/contact' className='linkk' > <button className='navbtns' id='lastbtn'>  Contact</button>    </Link>
              {/* <Link to='/contact' className='linkk' >  <button className='lastbutton'>Contact </button> </Link>  */}
        </div>
      </nav>
      
     
      




     <Routes>

      <Route  path='/contact' element={<Contact/>}/>
      <Route  path='/about' element={<Home/>}/>
      <Route  path='/users' element={<Users/>}/>
     </Routes>
    </div>
  );
}

export default App;
