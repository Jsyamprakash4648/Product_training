import React, { useState } from 'react'
import './Users.css'
import NewUser from './NewUser';
import ViewUser from './ViewUser';
import Edituser from './Edituser';

const Users = () => {

    const [users,setUsers]=useState([
        {
            id:1,
            name:'syam',
            username:'syam1122'
        },
        {
            id:2,
            name:'satya',
            username:'satya1122'
        },
        {
            id:3,
            name:'sriram',
            username:'sriram1122'
        }
    ]);

    const [newuser1,setnewusers1]=useState('');
     const [newusername2,setnewusersname2]=useState('');

    function Addnewuser()
    {
        const id=users.length?users[users.length-1].id+1:1;
        const userX={id:id,name:newuser1,username:newusername2};
        const listitems=[...users,userX];
        setUsers(listitems)
    }
    const handleSubmit=(e)=>
        {
            e.preventDefault();

            if(newuser1==''|| newusername2==='')return '';

            Addnewuser();
           setnewusers1('')
           setnewusersname2('')
            
         
        }

    function handledelete(idd)
    {
            const newlist=users.filter((user)=>user.id!==idd)
            setUsers(newlist);


    }
   const [edituser,setnewedituser]=useState('');

   const [editmode,seteditmode]=useState(true);

    function handleEdit(iddd)
    {
        const x=users.filter((user)=>user.id===iddd);
          setnewedituser(x);
          seteditmode(false)
        console.log(x);
    }

    function cancelbutton()
    {
        seteditmode(true)
    }

    function updatenewuser(idddd)
    {  
            const AB=users.filter((user)=>user.id===idddd);
            console.log(edituser[0].name);
            console.log(edituser[0].username);
            //console.log(AB[0].id);
            if(edituser[0].name=='' || edituser[0].username=='')return '';

            if(AB[0].id===idddd)
                {
                    //const newuser2={id:AB[0].id,name:edituser[0].name,username:edituser[0].username};
                    AB[0].name=edituser[0].name;
                    AB[0].username=edituser[0].username;
                    seteditmode(true)

                    
                    
                }
                
            
// console.log(AB)
            //  
            //  setUsers(newuser2);
    }

   

  return (
    <div className='mainbox'>
       <h1 >welcome to about screen of user management</h1>

    <h1>User Component</h1>
       <div className='boxcontents'>

        {editmode?(<NewUser
                    handleSubmit={handleSubmit}
                    setnewusers1={setnewusers1}
                    newuser1={newuser1}
                    newusername2={newusername2}
                    setnewusersname2={setnewusersname2}
                     />
                    ):
                    (<Edituser 
                        cancelbutton={cancelbutton}
                        edituser={edituser}
                        setnewedituser={setnewedituser}
                        setnewusersname2={setnewusersname2}
                        setnewusers1={setnewusers1}
                        updatenewuser={updatenewuser}
                        />)
                        
                        }
                    
                    

                     <ViewUser
                     users={users}
                     handleEdit={handleEdit}
                     handledelete={handledelete} />

       </div>
        

    </div>
  )
}

export default Users