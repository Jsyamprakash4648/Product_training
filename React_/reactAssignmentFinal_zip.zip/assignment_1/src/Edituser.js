import React from 'react'

const Edituser = ({cancelbutton,edituser,setnewedituser,updatenewuser}) => {
  return (
    <div className='box1'>
                        <form >
                        <h1>Edit user</h1>
                        <label>Name</label><br/>

                        <input 
                             type='text'
                             value={edituser[0].name}
                              onChange={(e) => setnewedituser([{ ...edituser[0], name: e.target.value }])}
                            
                        />
 
                        <br/><br/>

                        <label>Username</label><br/>
                        <input 
                             type='text'
                            //  value={edituser.length > 0 ? edituser[0].username: ''}
                            value={edituser[0].username }
                            onChange={(e) => setnewedituser([{ ...edituser[0], username: e.target.value }])}
                            
                        />

                        < button   className='addnewuserbutton' onClick={()=>updatenewuser(edituser[0].id)} type='button' >Update user</button>
                        <button  onClick={()=>cancelbutton()} className='cnclbtn' >Cancel</button>
                        </form>
                            
                     </div>
  )
}

export default Edituser